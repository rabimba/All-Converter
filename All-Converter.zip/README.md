All-converter
===============

A FirefoxOS app to convert measurements


Feel free to fork.

Unit Conversion hasn't been added as need to add API for realtime currnecy rate, and too lazy to do that now.
